<?php

class SolutionModel extends ZysModel{

    private $g_table = 'solution';

    public function __construct() {
        parent::__construct($this->g_table);
    }

    /**
     * 添加 解决方案
     * @param $data
     * @return bool
     * @author Wen
     */

    public function CreOne( $data )
    {
        return $this->add( $data );
    }


}