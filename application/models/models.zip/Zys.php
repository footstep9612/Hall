<?php

class ZysModel extends Model {
	public function __construct($str='') {
		parent::__construct($str);
	}
}
