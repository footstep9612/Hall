<?php

/**
 * ******************************
 * Class MaterialController
 * 商品素材库
 * ******************************
 * Created by PhpStorm.
 * User: wen
 * Date: 2017/5/20
 * Time: 21:07
 */
class MaterialController extends PublicController {

    public function init() {
        parent::init();
//        $this->_goods_model = new MaterialModel( 'goods' );
//        $this->_goods_relation_model = new GoodsRelationModel( 'goods_relation' );
//        $this->_quota_model = new QuotaModel( 'quota' );
//        $this->_task_model = new TaskModel( 'task' );
    }

    /**
     * 枚举值
     * goods_type       商品类型 1 闲置新设备 2 二手设备
     * goods_status     商品状态 0 待发布 1 发布 2 取消发布 3 废弃的
     * goods_source     商品所属 0 自有 1 代销
     * goods_purpose    所属库 0 正式的 1 虚拟 2 素材
     */

    /**
     * 发布
     * 取消发布
     * @param int   g_id      商品数据id
     * @param int   g_s       商品状态    1 发布 2 取消发布
     * @return bool
     * @author Wen
     */
    public function MaterialUpdAction() {



        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data)) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        if (!empty($data['token'])) {
            unset($data['token']);
        }
        if (!isset($data['g_id']) || !is_numeric($data['g_id']) || !isset($data['g_s']) || !is_numeric($data['g_s'])) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        $u_name = $this->user['username'];
        $u_id = $this->user['user_main_id'];
        // 判断 quota 表中是否存在、存在、修改 不存在 添加
        switch ($data['g_s']) {
            case 1:
                // 发布 判断是否存在、
                $where_g_r = array(
                    'del_flag' => 0,
                    'goods_id' => $data['g_id'],
                );
                // 注意： 一期这里只考虑APP发布出售的时候的是一个商品、用 SelOne
                $res_g_r = $this->_goods_relation_model->SelOne($where_g_r);
                // 不存在有效数据
                if (!$res_g_r['target_pk']) {
                    // 获取goods表的数据
                    $res_g_l = $this->_goods_model->SelOne(array('goods_id' => $data['g_id'], 'goods_purpose' => 2));
                    $res_g_l_json = json_decode($res_g_l['goods_view_json'], true);
                    $goodsList[] = $res_g_l_json;
                    // 处理数据
                    $userBasic['userId'] = $u_id;
                    $userBasic['sex'] = '';
                    $userBasic['avatar'] = '';
                    $userBasic['nickName'] = '';
                    $userBasic['organization'] = '';
                    $userBasic['profession'] = '';
                    $userBasic['isAttention'] = '';
                    $userBasic['location'] = '';
                    $userBasic['fansCount'] = '';
                    $userBasic['attentionCount'] = '';
                    $userBasic['userLevel'] = '';
                    $userBasic['userName'] = '';
                    $userBasic['balance'] = '';
                    // 明确数据
                    $data_q_desc['id'] = '';                           // quota数据id
                    $data_q_desc['businessType'] = 23;                           // 交易类型
                    $data_q_desc['status'] = '';                           // 新提交 / 发布
                    $data_q_desc['title'] = $res_g_l['goods_title'];      //
                    $data_q_desc['descrition'] = '';                           // 描述
                    $data_q_desc['type'] = 0;                            //
                    $data_q_desc['customerId'] = $res_g_l['org_id'];           // 供应商id
                    $data_q_desc['isMy'] = '';                           //
                    $data_q_desc['endDate'] = '';                           // 结束时间
                    $data_q_desc['scope'] = 1;                            // 1期 默认直发平台
                    $data_q_desc['goodsList'] = $goodsList;
                    $data_q_desc['userBasic'] = $userBasic;
                    $data_q_desc['reason'] = '';
                    $data_q_desc['createTime'] = date('Y-m-d H:i:s', time());
                    $data_q_desc['userName'] = $u_name;
                    $data_q_desc['userId'] = $u_id;
                    $data_q_desc['nickName'] = '';
                    // 添加数据到 quota表 在添加数据到 goods_relation
                    $data_q = array(
                        'user_main_id' => $u_id,
                        'quote_clue_desc' => json_encode($data_q_desc),
                        'quote_tran_type' => 23,
                        'quote_target_name' => $res_g_l['goods_title'],
                        'status' => 1,
                        'state_history' => '',
                        'created_at' => date('Y-m-d H:i:s', time()),
                        'updated_at' => date('Y-m-d H:i:s', time()),
                        'updated_by' => $u_name,
                        'del_flag' => 0,
                        'organization_id' => $res_g_l['org_id'],
                        'scope' => 1,
                    );
                    $res_q = $this->_quota_model->CreOne($data_q);
                    if (!$res_q) {
                        $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
                        echo json_encode($arr);
                        die();
                    }
                    /*                     * ********************************************** */
                    // 搜索引擎添加一条数据 走java接口
                    $data_java_1 = array(
                        'demandId' => $res_q,
                        'title' => $res_g_l['goods_title'],
                        'type' => 2,
                        'keyword' => '',
                        'userId' => $u_id,
                        'demand' => json_encode($data_q_desc),
                    );
                    $mongo_res = mongo()->collection('requirement')->insert($data_java_1);
                    $mongo_res_id = mongo()->collection('requirement')->find(mongo()->getInsertId());
                    $data_java_1['id'] = $mongo_res_id;
                    $data_java_2[] = $data_java_1;
                    $url = Yaf_Application::app()->getConfig()->quotasync;
                    $result = PostData($url, $data_java_2, true);
                    /*                     * ********************************************** */
                    // 添加数据到 goods_relation
                    $data_g_r = array(
                        'target_type' => 2,
                        'target_pk' => $res_q,
                        'goods_id' => $data['g_id'],
                        'search_code' => $mongo_res_id,
                        'del_flag' => 0,
                        'updated_by' => $u_name,
                    );
                    $res = $this->_goods_relation_model->CreOne($data_g_r);
                    if (!$res) {
                        $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
                        echo json_encode($arr);
                        die();
                    }
                }
                // 存在有效数据
                if ($res_g_r['target_pk']) {
                    switch ($res_g_r['target_type']) {
                        case 1:
                            // 是quota提交的数据 修改quota表中的状态
                            $where_q = array(
                                'quota_id' => $res_g_r['target_pk'],
                                'del_flag' => 0,
                                'status' => 6
                            );
                            $res_o_q = $this->_quota_model->OneQuota($where_q);
                            // 准备操作记录数据 -- 记录操作 状态 原因 操作者 时间
                            $his_n = array(
                                'time' => date('Y-m-d H:i:s', time()),
                                'u_name' => $u_name,
                                'status' => 1,
                                'reason' => '上架操作',
                            );
                            $his_o = json_decode($res_o_q['state_history'], true);
                            if ($his_o && $his_o != 'null') {
                                array_unshift($his_o, $his_n);
                            } else {
                                $his_o[] = $his_n;
                            }
                            $his = json_encode($his_o, JSON_UNESCAPED_UNICODE);
                            //修改
                            $data_q = array(
                                'del_flag' => 0,
                                'status' => 1,
                                'state_history' => $his,
                                'updated_by' => $u_name,
                            );
                            $res = $this->_quota_model->UpdOne($where_q, $data_q);
                            /*                             * ********************************************** */
                            $res_q = $this->_quota_model->OneQuota(array('del_flag' => 0, 'status' => 1, 'quota_id' => $res_g_r['target_pk']));
                            $res_g_l = $this->_goods_model->SelOne(array('goods_id' => $data['g_id'], 'goods_purpose' => 2));
                            // 搜索引擎添加一条数据 走java接口
                            $data_java_1 = array(
                                'demandId' => $res_g_r['target_pk'],
                                'title' => $res_g_l['goods_title'],
                                'type' => 2,
                                'keyword' => '',
                                'userId' => $u_id,
                                'demand' => $res_q['quote_clue_desc'],
                            );
                            $mongo_res = mongo()->collection('requirement')->insert($data_java_1);
                            $mongo_res_id = mongo()->collection('requirement')->find(mongo()->getInsertId());
                            $data_java_1['id'] = $mongo_res_id;
                            $data_java_2[] = $data_java_1;
                            $url = Yaf_Application::app()->getConfig()->quotasync;
                            $result = PostData($url, $data_java_2, true);
                            /*                             * ********************************************** */
                            // 修改goods_relation中的code
                            $data_g_relation = array(
                                'search_code' => $mongo_res_id,
                                'updated_by' => $u_name,
                            );
                            $res = $this->_goods_relation->UpdOne($where_g_r, $data_g_relation);
                            break;
                        case 2:
                            // 平台派发任务
                            $res = true;
                            break;
                        case 3:
                            // 自建任务
                            // 获取goods表的数据
                            $res_g_l = $this->_goods_model->SelOne(array('goods_id' => $data['g_id'], 'goods_purpose' => 2));
                            $res_g_l_json = json_decode($res_g_l['goods_view_json'], true);
                            $goodsList[] = $res_g_l_json;
                            // 处理数据
                            $userBasic['userId'] = $u_id;
                            $userBasic['sex'] = '';
                            $userBasic['avatar'] = '';
                            $userBasic['nickName'] = '';
                            $userBasic['organization'] = '';
                            $userBasic['profession'] = '';
                            $userBasic['isAttention'] = '';
                            $userBasic['location'] = '';
                            $userBasic['fansCount'] = '';
                            $userBasic['attentionCount'] = '';
                            $userBasic['userLevel'] = '';
                            $userBasic['userName'] = '';
                            $userBasic['balance'] = '';
                            // 明确数据
                            $data_q_desc['id'] = '';                           // quota数据id
                            $data_q_desc['businessType'] = 23;                           // 交易类型
                            $data_q_desc['status'] = '';                           // 新提交 / 发布
                            $data_q_desc['title'] = $res_g_l['goods_title'];      //
                            $data_q_desc['descrition'] = '';                           // 描述
                            $data_q_desc['type'] = 0;                            //
                            $data_q_desc['customerId'] = $res_g_l['org_id'];           // 供应商id
                            $data_q_desc['isMy'] = '';                           //
                            $data_q_desc['endDate'] = '';                           // 结束时间
                            $data_q_desc['scope'] = 1;                            // 1期 默认直发平台
                            $data_q_desc['goodsList'] = $goodsList;
                            $data_q_desc['userBasic'] = $userBasic;
                            $data_q_desc['reason'] = '';
                            $data_q_desc['createTime'] = date('Y-m-d H:i:s', time());
                            $data_q_desc['userName'] = $u_name;
                            $data_q_desc['userId'] = $u_id;
                            $data_q_desc['nickName'] = '';
                            // 添加数据到 quota表 在添加数据到 goods_relation
                            $data_q = array(
                                'user_main_id' => $u_id,
                                'quote_clue_desc' => json_encode($data_q_desc),
                                'quote_tran_type' => 23,
                                'quote_target_name' => $res_g_l['goods_title'],
                                'status' => 1,
                                'state_history' => '',
                                'created_at' => date('Y-m-d H:i:s', time()),
                                'updated_at' => date('Y-m-d H:i:s', time()),
                                'updated_by' => $u_name,
                                'del_flag' => 0,
                                'organization_id' => $res_g_l['org_id'],
                                'scope' => 1,
                            );
                            $res_q = $this->_quota_model->CreOne($data_q);
                            if (!$res_q) {
                                $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
                                echo json_encode($arr);
                                die();
                            }
                            /*                             * ********************************************** */
                            // 搜索引擎添加一条数据 走java接口
                            $data_java_1 = array(
                                'demandId' => $res_q,
                                'title' => $res_g_l['goods_title'],
                                'type' => 2,
                                'keyword' => '',
                                'userId' => $u_id,
                                'demand' => json_encode($data_q_desc),
                            );
                            $mongo_res = mongo()->collection('requirement')->insert($data_java_1);
                            $mongo_res_id = mongo()->collection('requirement')->find(mongo()->getInsertId());
                            $data_java_1['id'] = $mongo_res_id;
                            $data_java_2[] = $data_java_1;
                            $url = Yaf_Application::app()->getConfig()->quotasync;
                            $result = PostData($url, $data_java_2, true);
                            /*                             * ********************************************** */
                            // 修改 goods_relation 的数据
                            $where_g_r_o = array(
                                'target_type' => 3,
                                'del_flag' => 0,
                                'goods_id' => $data['g_id'],
                            );
                            $data_g_r_o = array(
                                'del_flag' => 1,
                                'updated_by' => $u_name,
                            );
                            $res_g_r_o = $this->_goods_relation_model->UpdOne($where_g_r_o, $data_g_r_o);
                            if (!$res_g_r_o) {
                                $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
                                echo json_encode($arr);
                                die();
                            }
                            // 添加数据到 goods_relation
                            $data_g_r = array(
                                'target_type' => 1,
                                'target_pk' => $res_q,
                                'goods_id' => $data['g_id'],
                                'del_flag' => 0,
                                'search_code' => $mongo_res_id,
                                'updated_by' => $u_name,
                            );
                            $res = $this->_goods_relation_model->CreOne($data_g_r);
                            break;
                        default:
                            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                            echo json_encode($arr);
                            die();
                    }
                }
                break;
            case 2:
                // 取消发布、先改 goods_relation 表、再改 quota 表
                $where_g_r = array(
                    'target_type' => array('in', '1,2'),
                    'del_flag' => 0,
                    'goods_id' => $data['g_id'],
                );
                $res_g_r_r = $this->_goods_relation_model->SelOne($where_g_r);
                if (!$res_g_r_r) {
                    $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '不存在数据');
                    echo json_encode($arr);
                    die();
                }
                switch ($res_g_r_r['target_type']) {
                    case 1:
                        // 判断 是否在 goods_relation 中存在状态为三的
                        $where_g_p = array(
                            'target_type' => array('in', '3'),
                            'del_flag' => 1,
                            'goods_id' => $data['g_id'],
                        );
                        $res_g_p = $this->_goods_relation_model->SelOne($where_g_p);
                        // 是原 quota 的数据
                        if (!$res_g_p) {
                            // 是quota的数据
                            $where_q = array(
                                'quota_id' => $res_g_r_r['target_pk'],
                                'del_flag' => 0,
                                'status' => 1
                            );
                            $res_o_q = $this->_quota_model->OneQuota($where_q);
                            // 准备操作记录数据 -- 记录操作 状态 原因 操作者 时间
                            $his_n = array(
                                'time' => date('Y-m-d H:i:s', time()),
                                'u_name' => $u_name,
                                'status' => 6,
                                'reason' => '下架操作',
                            );
                            $his_o = json_decode($res_o_q['state_history'], true);
                            if ($his_o && $his_o != 'null') {
                                array_unshift($his_o, $his_n);
                            } else {
                                $his_o[] = $his_n;
                            }
                            $his = json_encode($his_o, JSON_UNESCAPED_UNICODE);
                            //修改
                            $data_q = array(
                                'del_flag' => 0,
                                'status' => 6,
                                'state_history' => $his,
                                'updated_by' => $u_name,
                            );
                            $res = $this->_quota_model->UpdOne($where_q, $data_q);
                            /*                             * ********************************************** */
                            // 搜索引擎添加一条数据 走java接口
                            $result = GetData(Yaf_Application::app()->getConfig()->quotasyncdel . $res_g_r_r['search_code']);
                            /*                             * ********************************************** */
                            break;
                        }
                        // 是自建任务的数据
                        if ($res_g_p) {
                            // 自建任务
                            // 修改quota的数据为失效状态
                            $where_q = array(
                                'quota_id' => $res_g_r_r['target_pk'],
                                'del_flag' => 0,
                                'status' => 1
                            );
                            $res_o_q = $this->_quota_model->OneQuota($where_q);
                            if (!$res_o_q) {
                                $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '该商品已在出售中、不能经行下架操作');
                                echo json_encode($arr);
                                die();
                            }
                            // 准备操作记录数据 -- 记录操作 状态 原因 操作者 时间
                            $his_n = array(
                                'time' => date('Y-m-d H:i:s', time()),
                                'u_name' => $u_name,
                                'status' => 6,
                                'reason' => '下架操作',
                            );
                            $his_o = json_decode($res_o_q['state_history'], true);
                            if ($his_o && $his_o != 'null') {
                                array_unshift($his_o, $his_n);
                            } else {
                                $his_o[] = $his_n;
                            }
                            $his = json_encode($his_o, JSON_UNESCAPED_UNICODE);
                            //修改
                            $data_q = array(
                                'del_flag' => 1,
                                'status' => 6,
                                'state_history' => $his,
                                'updated_by' => $u_name,
                            );
                            $res_q_n = $this->_quota_model->UpdOne($where_q, $data_q);
                            if (!$res_q_n) {
                                $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '修改发布信息失败！');
                                echo json_encode($arr);
                                die();
                            }
                            // 修改 goods_relation
                            $where_g_r_o = array(
                                'target_type' => 1,
                                'del_flag' => 0,
                                'goods_id' => $data['g_id'],
                                'target_pk' => $res_g_r_r['target_pk'],
                            );
                            $data_g_r_o = array(
                                'del_flag' => 1,
                                'updated_by' => $u_name,
                            );
                            $res_g_r_o = $this->_goods_relation_model->UpdOne($where_g_r_o, $data_g_r_o);
                            if (!$res_g_r_o) {
                                $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '修改发布信息失败！');
                                echo json_encode($arr);
                                die();
                            }
                            $where_g_r_n = array(
                                'target_type' => 3,
                                'del_flag' => 1,
                                'goods_id' => $data['g_id'],
                            );
                            $data_g_r_n = array(
                                'del_flag' => 0,
                                'updated_by' => $u_name,
                            );
                            $res = $this->_goods_relation_model->UpdOne($where_g_r_n, $data_g_r_n);
                            /*                             * ********************************************** */
                            // 搜索引擎添加一条数据 走java接口
                            $result = GetData(Yaf_Application::app()->getConfig()->quotasyncdel . $res_g_p['search_code']);
                            /*                             * ********************************************** */
                            break;
                        }
                    case 2:
                        // 是任务寻源回来的数据 // 平台派发任务
                        $res = true;
                        break;
                }
                break;
            default:
                $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                echo json_encode($arr);
                die();
        }
        if (!$res) {
            $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
            echo json_encode($arr);
            die();
        }
        switch ($data['g_s']) {
            case 1:
                // 上架 将goods 虚拟 待发布/取消发布 修改为 正式 发布
                $where_g = array(
                    'goods_id' => $data['g_id'],
                    'goods_status' => array('in', '0,2'),
                    'goods_purpose' => 2,
                );
                $data_g = array(
                    'goods_status' => 1,
                    'goods_purpose' => 0
                );
                break;
            case 2:
                // 下架 将goods修改为虚拟 待发布
                $where_g = array(
                    'goods_id' => $data['g_id'],
                    'goods_status' => 1,
                    'goods_purpose' => 0,
                );
                $data_g = array(
                    'goods_status' => 2,
                    'goods_purpose' => 2,
                );
                break;
            default:
                $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                echo json_encode($arr);
                die();
        }
        $res_g_u = $this->_goods_model->UpdOne($where_g, $data_g);
        if (!$res_g_u) {
            $arr = array('code' => '-103', 'message' => '操作失败', 'data' => '操作失败');
            echo json_encode($arr);
            die();
        }
        $arr = array('code' => '0', 'message' => '成功', 'data' => '操作成功');
        echo json_encode($arr);
        die();
    }

    /**
     * 商品库列表
     * @param int   g_f     来源 1 虚拟商品 2 素材商品 3 正式商品
     * @param int   g_p     类型
     * * @param g_f=1  g_p=10
     * * @param g_f=2  g_p=20 所有 g_p=21 项目任务 g_p=22 供求信息 g_p=23 自建任务
     * * @param g_f=3  g_p=30
     * @param s
     * @param l
     * @return array
     * @author Wen
     */
    public function MaterialListAction() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data)) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        if (!empty($data['token'])) {
            unset($data['token']);
        }
        if (false == isset($data['g_f']) || false == is_numeric($data['g_f']) || false == isset($data['g_p']) || false == is_numeric($data['g_p'])) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        $start = !empty($data['s']) ? trim($data['s']) : 0;
        $limit = !empty($data['l']) ? trim($data['l']) : 10;
        // 虚拟商品
        if ($data['g_f'] == 1 && $data['g_p'] == 10) {
            $where_g = array(
                'goods_purpose' => 1,
            );
            $res['num'] = $this->_goods_model->SelCount($where_g);
            if (!$res['num']) {
                $arr = array('code' => '-100', 'message' => '成功', 'data' => '暂时没有数据');
                echo json_encode($arr);
                die();
            }
            $res = $this->_goods_model->SelList(null, $where_g, $start, $limit);
        }
        // 素材商品
        if ($data['g_f'] == 2 && is_numeric($data['g_p'])) {
            if ($data['g_p'] == 20) {
                // 所有商品
                $where_g = array(
                    'goods_purpose' => 2,
                    'goods_status' => array('in', '0,2')
                );
                $res['num'] = $this->_goods_model->SelCount($where_g);
                if (!$res['num']) {
                    $arr = array('code' => '-100', 'message' => '成功', 'data' => '暂时没有数据');
                    echo json_encode($arr);
                    die();
                }
                $res['data'] = $this->_goods_model->SelList(null, $where_g, $start, $limit);
            }
            if ($data['g_p'] == 21) {
                // 项目任务
                $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                echo json_encode($arr);
                die();
            }
            if ($data['g_p'] == 22) {
                // 供求信息
                $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                echo json_encode($arr);
                die();
            }
            if ($data['g_p'] == 23) {
                // 自建任务
                $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
                echo json_encode($arr);
                die();
            }
        }
        // 正式商品
        if ($data['g_f'] == 3 && $data['g_p'] == 30) {
            $where_g = array(
                'goods_purpose' => 0,
                'goods_status' => 1
            );
            $res['num'] = $this->_goods_model->SelCount($where_g);
            if (!$res['num']) {
                $arr = array('code' => '-100', 'message' => '成功', 'data' => '暂时没有数据');
                echo json_encode($arr);
                die();
            }
            $res['data'] = $this->_goods_model->SelList(null, $where_g, $start, $limit);
        }
        if (!$res) {
            $arr = array('code' => '-100', 'message' => '成功', 'data' => '暂时没有数据');
            echo json_encode($arr);
            die();
        }
        foreach ($res['data'] as $r_k => $r_v) {
            $res['data'][$r_k]['goods_view_json'] = json_decode($r_v['goods_view_json'], true);
        }
        $arr = array('code' => '0', 'message' => '成功', 'data' => $res);
        echo json_encode($arr);
        die();
    }

    /**
     * 根据id 获取设备信息
     * @param post => string id 设备id
     * @return array
     * @author Wen
     */
    public function GetDetailAction() {
        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data)) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        if (!empty($data['token'])) {
            unset($data['token']);
        }
        if (!isset($data['id'])) {
            $arr = array('code' => '-101', 'message' => '参数不完整', 'data' => '参数有误');
            echo json_encode($arr);
            die();
        }
        // 获取数据
        $res = mongo()->table('goods')->find($data['id']);
        if (!$res) {
            // 取 mysql 数据库
            $result = $this->_goods_model->SelOne(array('goods_relative_url' => $data['id']));
            if (!$result) {
                $arr = array('code' => '-100', 'message' => '成功', 'data' => '暂时没有数据');
                echo json_encode($arr);
                die();
            }
            $res = json_decode($result['goods_view_json'], true);
        }
        // 获取供应商信息
        if (isset($res['orgId']) && $res['orgId']) {
            // 处理数据
            $_org = new OrganizationModel('organization');
            $filed_org = 'org_name,org_contact_person,org_contact_telno';
            $where_org = array('organization_id' => $res['orgId']);
            $org_data = $_org->OrgSelOne($filed_org, $where_org);
            if ($org_data) {
                $res['org'] = $org_data;
            }
        }
        $arr = array('code' => '0', 'message' => '成功', 'data' => $res);
        echo json_encode($arr);
        die();
    }

}
